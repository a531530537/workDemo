<template>
  <router-view></router-view>
</template>
<style>
@import "./styles/index.css";

#app {
  height: 100%;
}
body {
  height: 100%;
}
html {
  height: 100%;
}
</style>
